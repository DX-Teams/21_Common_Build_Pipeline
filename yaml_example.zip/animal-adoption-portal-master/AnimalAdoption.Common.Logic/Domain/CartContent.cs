﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalAdoption.Common.Logic
{
    public class CartContent
    {
        public int Id { get; set; }
        public int Quantity { get; set; }
        public string Name { get; set; }
    }
}
