﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalAdoption.Common.Logic
{
    public class Configuration
    {
        public string GlobalPassword { get; set; }
    }
}
